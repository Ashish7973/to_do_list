This is very basic project in which i used 
** HTML
** CSS
** JavaScript
** PHP
** MySQL

/**** Made by Ashish Kumar ****\

-To run this project follow the below steps :

--First of all Download XAMPP and Install it,

    start 1.Apache server
          2.MySQL Server

(Make Sure Your XAMPP server is started and working properly.)

1. Extract the folder and Paste it to the (local : C/XAMPP->htdocs)

2. Open your MySQL Workbench:
 3.1- create any connection;
 3.2- now, create a schema and name it as "to_do_list";
 3.3- now open 'tdl.sql' present in (XAMPP->htdocs->to_do_list_ak->tdl.sql);
 3.4- now select database as `tdl`;
 3.5- now run the code and close the Mysql.

3.Now type (localhost/to_do_list_ak) in new tab on Chrome;
 3.1- It will open Home Page of this system;
 3.2-BOOOOOMMMM--!!!!! now you can add new todo list and check which work is completed and can remove the completed work;

4.Now you are all set to use it's feature .
